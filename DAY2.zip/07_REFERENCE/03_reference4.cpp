void foo(int n)
{
	n = 20;
}
int main()
{
	int x = 100;
	foo(x);
}
