#include <iostream>

int main()
{
	int n = 0;

	// 사용자가 -1을 입력할때 까지 계속 입력 받고 싶다.
	while( 1 )
	{
		std::cin >> n;

		if ( n == 1 ) break;
	}
	
}