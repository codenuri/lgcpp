#include <iostream>

class Car
{
	int color = 0;
	static int cnt;
public:	
	Car() { ++cnt;}
	~Car() {--cnt;}

	void set_color(int c) { color = c;}

	static int get_count() { return cnt;} 	
};
int Car::cnt = 0;	

int main()
{	
	Car c1;
	Car c2;

	std::cout << Car::get_count() << std::endl; 
}

