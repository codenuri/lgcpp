#include <stdio.h>

int add(int a, int b) 
{
	return a + b;
}

int sub(int a, int b)
{
	return a - b;
}

int main()
{ 
	int n1 = add(1, 2);
	int n2 = sub(1, 2);
}
