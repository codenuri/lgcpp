#include <iostream>

class Point
{
	int x, y;
public:
	Point(int a, int b) : x{a}, y{b} {}

	// 상수 멤버 함수가 아닙니다.
	void set(int a, int b) 
	{ 
		x = a; 
		y = b; 
	}

	// 상수 멤버 함수 입니다.
	void print() const
	{	
		std::cout << x << ", " << y << std::endl;
	}
}; 
int main() 
{
	Point p1(1, 2);
	const Point p2(1, 2);

	p1.set(10,20);
	p1.print();

	p2.set(10,20);
	p2.print();
}

