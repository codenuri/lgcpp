﻿// structural binding declaration
// 31 page

struct Point
{
	int x, y;
};
int main()
{
	Point pt = { 1,2 };

	int x = pt.x;
	int y = pt.y;
}
