﻿// 3_변수1
#include <iostream>

// C++ 은 C언어의 변수 관련 문법을 더욱 발전시켰습니다.
// 22 page ~

int main()
{
	// #1. 새로운 타입
	

	// #2. 2진수 표기법, digit separator
	int n1 = 1;
	int n2 = 1000000;
}
