// nullptr. 24 page
int main()
{
	int  n1 = 0;
	int* p1 = 0;
}