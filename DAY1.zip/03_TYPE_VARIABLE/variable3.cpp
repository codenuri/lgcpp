// struct - 25 page

struct Point 
{
	int x;
	int y;
};

int main()
{
	struct Point p1;
	Point p2; 
}
