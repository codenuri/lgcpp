// string
// 32 page

#include <cstring>

int main()
{
	char s1[] = "hello";
	char s2[] = "world";

	if ( s1 == s2 ) {}

	s1 = s2;
}