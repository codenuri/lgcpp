﻿// 18page
#include <iostream>

int main()
{
	int n = 10;
	std::cout << n << std::endl; // 
	std::cout << n << std::endl; // 
	std::cout << n << std::endl; // 
	std::cout << n << std::endl; // 
}
