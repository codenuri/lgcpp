﻿#include <iostream>
// 50 page

int main()
{
	int n = 3;

	double* p = &n; // ??

}
