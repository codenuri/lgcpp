﻿// 70 page

int add1(int a, int b)
{
	return a + b;
}

int add2(int a, int b)
{
	return a + b;
}

int main()
{
	int n1 = add1(1,2);	
	int n2 = add2(1,2);
}