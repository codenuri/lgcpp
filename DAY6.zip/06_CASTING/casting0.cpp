#include <iostream>

int main()
{
	// 캐스팅을 사용하는 이유 #1. 
	double d = 3.4;
	int a = d; 


	// 캐스팅을 사용하는 이유 #2
	int n = 0x11223344;

	printf("%x\n", n);
}