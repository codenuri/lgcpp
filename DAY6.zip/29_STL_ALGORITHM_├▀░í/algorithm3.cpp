#include <algorithm>
#include <vector>
#include <string>
#include <iostream>

int main()
{
	std::string name = "홍길동";
	std::string s = "홍길동";

	if ( name == s ) 
		std::cout << "같음\n";
	else
		std::cout << "다름\n";
}