#include <vector>
#include <string>
#include <iostream>
#include <algorithm>
#include "People.h"

std::vector<People*> v = { new People("kim",  20), 
						   new People("lee",  30),
						   new People("park", 40),
						   new People("choi", 35) };

void print()
{
	int i = 0;
	for( auto e : v)
	{
		std::cout << ++i << ". " << e->name << "(" << e->age << ")\n";
	}
}

int main()
{
	// #1. 실행해서 결과를 확인해 보세요. 
	//     vector 에 삽입된 순서인 kim-lee-park-choi 순서로 출력됩니다.
	print();

	// #2. v 의 내용을 나이순으로 정렬후, 출력(print())해 보세요.


	

}






