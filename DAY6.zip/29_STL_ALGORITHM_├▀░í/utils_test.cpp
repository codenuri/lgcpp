#include <iostream>
#include "utils.h"

void add(int menuid)    {}
void remove(int menuid) {}

int main()
{
	int year = current_year();

	std::cout << year << std::endl;

	PopupMenu* root = new PopupMenu("ROOT");
	PopupMenu* pm = new PopupMenu("고객관리");

	root->add(pm);

	pm->add(new MenuItem("추가", 11, add));
	pm->add(new MenuItem("삭제", 12, remove));

	root->command();
}
